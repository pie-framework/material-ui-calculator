# solvent
A calculator with equations and variables
